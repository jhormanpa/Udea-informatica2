#include <iostream>
using namespace std;

int main(){
cout <<"hola mundo";
return 0;
}
 

